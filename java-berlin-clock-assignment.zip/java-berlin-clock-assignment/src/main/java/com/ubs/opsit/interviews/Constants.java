package com.ubs.opsit.interviews;

public final class Constants {
    public static final int TIME_UNIT_FOR_ONE_LAMP = 5;
    public static final int NUMBER_OF_LAMPS_IN_HOURS_ROW = 4;
    public static final int NUBER_OF_LAMPS_IN_MINUTES_FIRST_ROW = 11;
    public static final int NUMBER_OF_ROWS_IN_MINUTES_SECOND_ROW = 4;
    public static final int NUMBER_OF_ROWS = 2;
    public static final String NEW_LINE = "\r\n";
}
