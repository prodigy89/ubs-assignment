package com.ubs.opsit.interviews.engine;

public interface ConversionEngine {
    String convert(int timeFactor);
}
